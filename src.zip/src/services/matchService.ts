import api from "../api/axiosConfig";

export const getMatches = async () => {
  const response = await api.get("/matches");
  return response.data;
};

export const getMatchById = async (matchId: number) => {
  const response = await api.get(`/matches/${matchId}`);
  return response.data;
};

export const createMatch = async (payload: {
  homeTeamId: number | null;
  awayTeamId: number | null;
  externalOpponentName: string;
  leagueId: number | null;
  matchDate: string;
  venue: string;
  matchType: string;
  notes: string;
  status: "UPCOMING" | "COMPLETED" | "CANCELLED";
}) => {
  const response = await api.post("/matches", payload);
  return response.data;
};

export const updateMatch = async (matchId: number, payload: any) => {
  const response = await api.put(`/matches/${matchId}`, payload);
  return response.data;
};

export const deleteMatch = async (matchId: number) => {
  const response = await api.delete(`/matches/${matchId}`);
  return response.data;
};