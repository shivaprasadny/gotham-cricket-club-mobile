import React, { useState } from "react";
import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import {
  forgotPassword,
  requestPasswordResetCode,
} from "../services/authService";

type Props = {
  navigation: any;
};

const ForgotPasswordScreen = ({ navigation }: Props) => {
  // Form fields
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Loading states
  const [sendingCode, setSendingCode] = useState(false);
  const [resetting, setResetting] = useState(false);

  // Request reset code
  const handleSendCode = async () => {
    if (!email.trim()) {
      Alert.alert("Error", "Please enter your email");
      return;
    }

    try {
      setSendingCode(true);

      const response = await requestPasswordResetCode(email.trim());

      // Auto-fill code input for easier testing
      setCode(response.resetCode);

      Alert.alert(
        "Reset Code",
        `Code: ${response.resetCode}\n\n${response.message}`
      );
    } catch (error: any) {
      Alert.alert(
        "Error",
        error?.response?.data?.message || "Failed to send reset code"
      );
    } finally {
      setSendingCode(false);
    }
  };

  // Reset password using email + code + new password
  const handleResetPassword = async () => {
    if (!email.trim()) {
  Alert.alert("Error", "Please enter your email");
  return;
}

if (!code.trim()) {
  Alert.alert("Error", "Please enter reset code");
  return;
}

if (!newPassword.trim()) {
  Alert.alert("Error", "Please enter new password");
  return;
}

if (!confirmPassword.trim()) {
  Alert.alert("Error", "Please confirm your password");
  return;
}

if (newPassword.trim() !== confirmPassword.trim()) {
  Alert.alert("Error", "Passwords do not match");
  return;
}
    try {
      setResetting(true);

      const response = await forgotPassword({
        email: email.trim(),
        code: code.trim(),
        newPassword: newPassword.trim(),
      });

      Alert.alert(
        "Success",
        typeof response === "string"
          ? response
          : "Password reset successful"
      );

      navigation.navigate("Login");
    } catch (error: any) {
      Alert.alert(
        "Error",
        error?.response?.data?.message || "Failed to reset password"
      );
    } finally {
      setResetting(false);
    }
  };

  return (
    // KeyboardAvoidingView helps keep fields visible above keyboard
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      {/* ScrollView keeps form usable on smaller screens */}
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Club logo */}
        <Image
          source={require("../../assets/logo.png")}
          style={styles.logo}
        />

        {/* Heading */}
        <Text style={styles.title}>Reset Password</Text>
        <Text style={styles.subtitle}>
          Request a code and set a new password
        </Text>

        {/* Reset form card */}
        <View style={styles.card}>
          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#7a7a7a"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

          {/* Send reset code button */}
          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={handleSendCode}
            disabled={sendingCode}
          >
            <Text style={styles.secondaryButtonText}>
              {sendingCode ? "Sending..." : "Send Reset Code"}
            </Text>
          </TouchableOpacity>

          <TextInput
            style={styles.input}
            placeholder="Reset Code"
            placeholderTextColor="#7a7a7a"
            value={code}
            onChangeText={setCode}
          />

          <TextInput
            style={styles.input}
            placeholder="New Password"
            placeholderTextColor="#7a7a7a"
            value={newPassword}
            onChangeText={setNewPassword}
            secureTextEntry
          />

          <TextInput
  style={styles.input}
  placeholder="Confirm Password"
  placeholderTextColor="#7a7a7a"
  value={confirmPassword}
  onChangeText={setConfirmPassword}
  secureTextEntry
/>

          {/* Reset password button */}
         <TouchableOpacity
  style={[
    styles.primaryButton,
    (resetting ||
      !email.trim() ||
      !code.trim() ||
      !newPassword.trim() ||
      !confirmPassword.trim()) && styles.buttonDisabled
  ]}
  onPress={handleResetPassword}
  disabled={
    resetting ||
    !email.trim() ||
    !code.trim() ||
    !newPassword.trim() ||
    !confirmPassword.trim()
  }
>
  <Text style={styles.primaryButtonText}>
    {resetting ? "Resetting..." : "Reset Password"}
  </Text>
</TouchableOpacity>

          {/* Back to login link */}
          <TouchableOpacity
            style={styles.linkButton}
            onPress={() => navigation.navigate("Login")}
          >
            <Text style={styles.linkText}>Back to Login</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default ForgotPasswordScreen;

const styles = StyleSheet.create({
  // Main screen background
  root: {
    flex: 1,
    backgroundColor: "#2b0540",
  },

  // Scroll container
  container: {
    flexGrow: 1,
    padding: 20,
    justifyContent: "center",
    paddingBottom: 40,
  },

  // Club logo
  logo: {
    width: 110,
    height: 110,
    resizeMode: "contain",
    alignSelf: "center",
    marginBottom: 18,
  },

  // Screen title
  title: {
    color: "#fff",
    fontSize: 28,
    fontWeight: "700",
    textAlign: "center",
    marginBottom: 8,
  },

  // Screen subtitle
  subtitle: {
    color: "#da9306",
    fontSize: 15,
    textAlign: "center",
    marginBottom: 20,
    fontWeight: "600",
  },

  // White form card
  card: {
    backgroundColor: "#fff",
    borderRadius: 20,
    padding: 20,
  },

  // Standard input field
  input: {
    borderWidth: 1,
    borderColor: "#d9d2e1",
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 12,
    fontSize: 15,
    color: "#111",
    backgroundColor: "#fafafa",
  },

  // Primary action button
  primaryButton: {
    backgroundColor: "#da9306",
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 4,
  },

  primaryButtonText: {
    color: "#2b0540",
    fontWeight: "700",
    textAlign: "center",
    fontSize: 16,
  },

  // Secondary action button
  secondaryButton: {
    backgroundColor: "#2b0540",
    paddingVertical: 14,
    borderRadius: 12,
    marginBottom: 12,
  },

  secondaryButtonText: {
    color: "#fff",
    fontWeight: "700",
    textAlign: "center",
    fontSize: 15,
  },

  // Bottom link button
  linkButton: {
    marginTop: 14,
  },

  linkText: {
    color: "#2b0540",
    textAlign: "center",
    fontWeight: "600",
  },
  buttonDisabled: {
  opacity: 0.5,
},
});