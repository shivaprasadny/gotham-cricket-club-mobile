import React, { useEffect, useMemo, useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import { createMatch } from "../services/matchService";
import { getTeams } from "../services/teamService";
import { getLeagues } from "../services/leagueService";

type Props = {
  navigation: any;
};

type Team = {
  id: number;
  teamName: string;
};

type League = {
  id: number;
  name: string;
  season: string;
  active: boolean;
};

type MatchStatus = "UPCOMING" | "COMPLETED" | "CANCELLED";

type MatchType =
  | "LEAGUE"
  | "FRIENDLY"
  | "PRACTICE"
  | "INTRA_CLUB"
  | "TOURNAMENT";

type MatchFormat =
  | "T20"
  | "T25"
  | "T30"
  | "T40"
  | "ODI"
  | "TEST"
  | "CUSTOM";

const MATCH_TYPES: MatchType[] = [
  "LEAGUE",
  "FRIENDLY",
  "PRACTICE",
  "INTRA_CLUB",
  "TOURNAMENT",
];

const MATCH_FORMATS: MatchFormat[] = [
  "T20",
  "T25",
  "T30",
  "T40",
  "ODI",
  "TEST",
  "CUSTOM",
];

const CreateMatchScreen = ({ navigation }: Props) => {
  // Dropdown data
  const [teams, setTeams] = useState<Team[]>([]);
  const [leagues, setLeagues] = useState<League[]>([]);

  // Main match fields
  const [homeTeamId, setHomeTeamId] = useState<number | null>(null);
  const [awayTeamId, setAwayTeamId] = useState<number | null>(null);
  const [externalOpponentName, setExternalOpponentName] = useState("");
  const [leagueId, setLeagueId] = useState<number | null>(null);
  const [venue, setVenue] = useState("");
  const [notes, setNotes] = useState("");
  const [matchFee, setMatchFee] = useState("");
  const [matchDate, setMatchDate] = useState<Date | null>(null);

  // Controlled temp state for match date picker
  const [tempMatchDate, setTempMatchDate] = useState<Date>(new Date());

  // Match configuration
  const [matchType, setMatchType] = useState<MatchType>("LEAGUE");
  const [matchFormat, setMatchFormat] = useState<MatchFormat>("T20");
  const [customFormat, setCustomFormat] = useState("");
  const [status, setStatus] = useState<MatchStatus>("UPCOMING");

  // Opponent type selection
  const [opponentMode, setOpponentMode] = useState<"EXTERNAL" | "CLUB">(
    "EXTERNAL"
  );

  // Picker visibility states
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showLeaguePicker, setShowLeaguePicker] = useState(false);
  const [showHomeTeamPicker, setShowHomeTeamPicker] = useState(false);
  const [showAwayTeamPicker, setShowAwayTeamPicker] = useState(false);
  const [showFormatPicker, setShowFormatPicker] = useState(false);

  // Submit state
  const [submitting, setSubmitting] = useState(false);

  // Match fee details
  const [matchFeeAmount, setMatchFeeAmount] = useState("");
  const [matchFeeDescription, setMatchFeeDescription] = useState("");
  const [matchFeeDueDate, setMatchFeeDueDate] = useState<Date | null>(null);

  // Controlled temp state for fee due date picker
  const [tempMatchFeeDueDate, setTempMatchFeeDueDate] = useState<Date>(
    new Date()
  );

  const [showMatchFeeDueDatePicker, setShowMatchFeeDueDatePicker] =
    useState(false);

  // Load teams and leagues when screen opens
  useEffect(() => {
    void loadDropdownData();
  }, []);

  const loadDropdownData = async () => {
    try {
      const [teamData, leagueData] = await Promise.all([
        getTeams(),
        getLeagues(),
      ]);

      setTeams(Array.isArray(teamData) ? teamData : []);
      setLeagues(Array.isArray(leagueData) ? leagueData : []);
    } catch (error) {
      console.log("CREATE MATCH LOAD ERROR:", error);
      Alert.alert("Error", "Failed to load teams or leagues");
    }
  };

  // Selected league display text
  const selectedLeagueName = useMemo(() => {
    if (leagueId === null) return "None";
    return (
      leagues.find((league) => league.id === leagueId)?.name || "Select league"
    );
  }, [leagueId, leagues]);

  // Selected home team display text
  const selectedHomeTeamName = useMemo(() => {
    return (
      teams.find((team) => team.id === homeTeamId)?.teamName ||
      "Select home team"
    );
  }, [homeTeamId, teams]);

  // Selected away team display text
  const selectedAwayTeamName = useMemo(() => {
    return (
      teams.find((team) => team.id === awayTeamId)?.teamName ||
      "Select away team"
    );
  }, [awayTeamId, teams]);

  // Final format value
  const finalMatchFormat =
    matchFormat === "CUSTOM" ? customFormat.trim() : matchFormat;

  // Create match handler
  const handleCreateMatch = async () => {
    if (!homeTeamId) {
      Alert.alert("Error", "Please select a home team");
      return;
    }

    if (!matchDate) {
      Alert.alert("Error", "Please select match date and time");
      return;
    }

    if (!venue.trim()) {
      Alert.alert("Error", "Please enter venue");
      return;
    }

    if (!finalMatchFormat) {
      Alert.alert("Error", "Please select or enter match format");
      return;
    }

    if (opponentMode === "CLUB") {
      if (!awayTeamId) {
        Alert.alert("Error", "Please select away team");
        return;
      }

      if (homeTeamId === awayTeamId) {
        Alert.alert("Error", "Home team and away team cannot be the same");
        return;
      }
    }

    if (opponentMode === "EXTERNAL" && !externalOpponentName.trim()) {
      Alert.alert("Error", "Please enter outside opponent name");
      return;
    }

    try {
      setSubmitting(true);

      const payload = {
        homeTeamId,
        awayTeamId: opponentMode === "CLUB" ? awayTeamId : null,
        externalOpponentName:
          opponentMode === "EXTERNAL" ? externalOpponentName.trim() : "",
        leagueId,
        matchDate: matchDate.toISOString(),
        venue: venue.trim(),
        matchType,
        matchFormat: finalMatchFormat,
        matchFee: matchFee.trim() ? Number(matchFee) : null,
        matchFeeAmount: matchFeeAmount.trim()
          ? Number(matchFeeAmount)
          : null,
        matchFeeDueDate: matchFeeDueDate
          ? matchFeeDueDate.toISOString()
          : null,
        matchFeeDescription: matchFeeDescription.trim(),
        notes: notes.trim(),
        status,
      };

      const response = await createMatch(payload);

      const notificationOpponentName =
        opponentMode === "CLUB"
          ? selectedAwayTeamName
          : externalOpponentName.trim();

      Alert.alert(
        "Success",
        typeof response === "string" ? response : "Match created successfully",
        [{ text: "OK", onPress: () => navigation.goBack() }]
      );
    } catch (error: any) {
      console.log("CREATE MATCH ERROR:", error?.response?.data || error);
      Alert.alert(
        "Error",
        error?.response?.data?.message ||
          error?.response?.data ||
          "Failed to create match"
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      {/* KeyboardAvoidingView helps move content upward when keyboard opens */}
      <KeyboardAvoidingView
        style={styles.screen}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 20}
      >
        {/* ScrollView lets user scroll when keyboard is open */}
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.title}>Create Match</Text>

          <Text style={styles.label}>Match Type</Text>
          <View style={styles.rowWrap}>
            {MATCH_TYPES.map((item) => (
              <TouchableOpacity
                key={item}
                style={[
                  styles.chipBtn,
                  matchType === item && styles.chipBtnSelected,
                ]}
                onPress={() => setMatchType(item)}
              >
                <Text
                  style={[
                    styles.chipText,
                    matchType === item && styles.chipTextSelected,
                  ]}
                >
                  {item}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>Match Format</Text>
          <TouchableOpacity
            style={styles.selectInput}
            onPress={() => setShowFormatPicker(true)}
          >
            <Text style={styles.selectInputText}>
              {matchFormat === "CUSTOM"
                ? customFormat || "Custom format"
                : matchFormat}
            </Text>
          </TouchableOpacity>

          {matchFormat === "CUSTOM" && (
            <TextInput
              style={styles.input}
              placeholder="Enter custom format"
              placeholderTextColor="#7a7a7a"
              value={customFormat}
              onChangeText={setCustomFormat}
            />
          )}

          <Text style={styles.label}>League (Optional)</Text>
          <TouchableOpacity
            style={styles.selectInput}
            onPress={() => setShowLeaguePicker(true)}
          >
            <Text style={styles.selectInputText}>{selectedLeagueName}</Text>
          </TouchableOpacity>

          <Text style={styles.label}>Home Team</Text>
          <TouchableOpacity
            style={styles.selectInput}
            onPress={() => setShowHomeTeamPicker(true)}
          >
            <Text style={styles.selectInputText}>{selectedHomeTeamName}</Text>
          </TouchableOpacity>

          <Text style={styles.label}>Opponent Setup</Text>
          <View style={styles.rowWrap}>
            <TouchableOpacity
              style={[
                styles.chipBtn,
                opponentMode === "EXTERNAL" && styles.chipBtnSelected,
              ]}
              onPress={() => {
                setOpponentMode("EXTERNAL");
                setAwayTeamId(null);
              }}
            >
              <Text
                style={[
                  styles.chipText,
                  opponentMode === "EXTERNAL" && styles.chipTextSelected,
                ]}
              >
                Outside Opponent
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.chipBtn,
                opponentMode === "CLUB" && styles.chipBtnSelected,
              ]}
              onPress={() => {
                setOpponentMode("CLUB");
                setExternalOpponentName("");
              }}
            >
              <Text
                style={[
                  styles.chipText,
                  opponentMode === "CLUB" && styles.chipTextSelected,
                ]}
              >
                Club vs Club
              </Text>
            </TouchableOpacity>
          </View>

          {opponentMode === "EXTERNAL" && (
            <>
              <Text style={styles.label}>Outside Opponent Name</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter outside opponent name"
                placeholderTextColor="#7a7a7a"
                value={externalOpponentName}
                onChangeText={setExternalOpponentName}
              />
            </>
          )}

          {opponentMode === "CLUB" && (
            <>
              <Text style={styles.label}>Away Team</Text>
              <TouchableOpacity
                style={styles.selectInput}
                onPress={() => setShowAwayTeamPicker(true)}
              >
                <Text style={styles.selectInputText}>
                  {selectedAwayTeamName}
                </Text>
              </TouchableOpacity>
            </>
          )}

          <Text style={styles.label}>Match Date & Time</Text>
          <TouchableOpacity
            style={styles.selectInput}
            onPress={() => {
              setTempMatchDate(matchDate || new Date());
              setShowDatePicker(true);
            }}
          >
            <Text style={styles.selectInputText}>
              {matchDate
                ? matchDate.toLocaleString()
                : "Select match date & time"}
            </Text>
          </TouchableOpacity>

          {showDatePicker && (
            <View style={styles.inlinePickerCard}>
              <DateTimePicker
                value={tempMatchDate}
                mode="datetime"
                display={Platform.OS === "ios" ? "inline" : "default"}
                onChange={(event, selectedDate) => {
                  if (selectedDate) {
                    setTempMatchDate(selectedDate);
                  }

                  if (Platform.OS !== "ios" && selectedDate) {
                    setMatchDate(selectedDate);
                    setShowDatePicker(false);
                  }
                }}
              />

              {Platform.OS === "ios" && (
                <View style={styles.pickerButtonsRow}>
                  <TouchableOpacity
                    style={styles.cancelBtn}
                    onPress={() => setShowDatePicker(false)}
                  >
                    <Text style={styles.cancelText}>Cancel</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.confirmBtn}
                    onPress={() => {
                      setMatchDate(tempMatchDate);
                      setShowDatePicker(false);
                    }}
                  >
                    <Text style={styles.confirmText}>Confirm</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}

          <Text style={styles.label}>Venue</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter venue"
            placeholderTextColor="#7a7a7a"
            value={venue}
            onChangeText={setVenue}
          />

          <Text style={styles.label}>Match Fee Per Player $(Optional)</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter fee amount per player"
            placeholderTextColor="#7a7a7a"
            value={matchFeeAmount}
            onChangeText={setMatchFeeAmount}
            keyboardType="numeric"
          />

          <Text style={styles.label}>Match Fee Due Date (Optional)</Text>
          <TouchableOpacity
            style={styles.input}
            onPress={() => {
              setTempMatchFeeDueDate(matchFeeDueDate || new Date());
              setShowMatchFeeDueDatePicker(true);
            }}
          >
            <Text style={styles.inputText}>
              {matchFeeDueDate
                ? matchFeeDueDate.toLocaleString()
                : "Select fee due date & time"}
            </Text>
          </TouchableOpacity>

          {showMatchFeeDueDatePicker && (
            <View style={styles.inlinePickerCard}>
              <DateTimePicker
                value={tempMatchFeeDueDate}
                mode="datetime"
                display={Platform.OS === "ios" ? "inline" : "default"}
                onChange={(event, selectedDate) => {
                  if (selectedDate) {
                    setTempMatchFeeDueDate(selectedDate);
                  }

                  if (Platform.OS !== "ios" && selectedDate) {
                    setMatchFeeDueDate(selectedDate);
                    setShowMatchFeeDueDatePicker(false);
                  }
                }}
              />

              {Platform.OS === "ios" && (
                <View style={styles.pickerButtonsRow}>
                  <TouchableOpacity
                    style={styles.cancelBtn}
                    onPress={() => setShowMatchFeeDueDatePicker(false)}
                  >
                    <Text style={styles.cancelText}>Cancel</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.confirmBtn}
                    onPress={() => {
                      setMatchFeeDueDate(tempMatchFeeDueDate);
                      setShowMatchFeeDueDatePicker(false);
                    }}
                  >
                    <Text style={styles.confirmText}>Confirm</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}

          <Text style={styles.label}>Match Fee Description (Optional)</Text>
          <TextInput
            style={[styles.input, styles.notesInput]}
            placeholder="Example: Pay before match day"
            placeholderTextColor="#7a7a7a"
            value={matchFeeDescription}
            onChangeText={setMatchFeeDescription}
            multiline
          />

          <Text style={styles.label}>Notes</Text>
          <TextInput
            style={[styles.input, styles.notesInput]}
            placeholder="Optional notes"
            placeholderTextColor="#7a7a7a"
            value={notes}
            onChangeText={setNotes}
            multiline
          />

          <Text style={styles.label}>Status</Text>
          <View style={styles.rowWrap}>
            {(["UPCOMING", "COMPLETED", "CANCELLED"] as MatchStatus[]).map(
              (item) => (
                <TouchableOpacity
                  key={item}
                  style={[
                    styles.chipBtn,
                    status === item && styles.chipBtnSelected,
                  ]}
                  onPress={() => setStatus(item)}
                >
                  <Text
                    style={[
                      styles.chipText,
                      status === item && styles.chipTextSelected,
                    ]}
                  >
                    {item}
                  </Text>
                </TouchableOpacity>
              )
            )}
          </View>

          <TouchableOpacity
            style={styles.submitBtn}
            onPress={handleCreateMatch}
            disabled={submitting}
          >
            <Text style={styles.submitBtnText}>
              {submitting ? "Creating..." : "Create Match"}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>

      {/* League Picker */}
      <Modal visible={showLeaguePicker} transparent animationType="fade">
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowLeaguePicker(false)}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Select League</Text>

            <TouchableOpacity
              style={styles.modalItem}
              onPress={() => {
                setLeagueId(null);
                setShowLeaguePicker(false);
              }}
            >
              <Text style={styles.modalItemText}>None</Text>
            </TouchableOpacity>

            {leagues.map((league) => (
              <TouchableOpacity
                key={league.id}
                style={styles.modalItem}
                onPress={() => {
                  setLeagueId(league.id);
                  setShowLeaguePicker(false);
                }}
              >
                <Text style={styles.modalItemText}>{league.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Pressable>
      </Modal>

      {/* Home Team Picker */}
      <Modal visible={showHomeTeamPicker} transparent animationType="fade">
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowHomeTeamPicker(false)}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Select Home Team</Text>

            {teams.map((team) => (
              <TouchableOpacity
                key={team.id}
                style={styles.modalItem}
                onPress={() => {
                  setHomeTeamId(team.id);
                  if (awayTeamId === team.id) {
                    setAwayTeamId(null);
                  }
                  setShowHomeTeamPicker(false);
                }}
              >
                <Text style={styles.modalItemText}>{team.teamName}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Pressable>
      </Modal>

      {/* Away Team Picker */}
      <Modal visible={showAwayTeamPicker} transparent animationType="fade">
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowAwayTeamPicker(false)}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Select Away Team</Text>

            {teams
              .filter((team) => team.id !== homeTeamId)
              .map((team) => (
                <TouchableOpacity
                  key={team.id}
                  style={styles.modalItem}
                  onPress={() => {
                    setAwayTeamId(team.id);
                    setShowAwayTeamPicker(false);
                  }}
                >
                  <Text style={styles.modalItemText}>{team.teamName}</Text>
                </TouchableOpacity>
              ))}
          </View>
        </Pressable>
      </Modal>

      {/* Format Picker */}
      <Modal visible={showFormatPicker} transparent animationType="fade">
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setShowFormatPicker(false)}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Select Match Format</Text>

            {MATCH_FORMATS.map((format) => (
              <TouchableOpacity
                key={format}
                style={styles.modalItem}
                onPress={() => {
                  setMatchFormat(format);
                  if (format !== "CUSTOM") {
                    setCustomFormat("");
                  }
                  setShowFormatPicker(false);
                }}
              >
                <Text style={styles.modalItemText}>{format}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Pressable>
      </Modal>
    </>
  );
};

export default CreateMatchScreen;

const styles = StyleSheet.create({
  // Full screen wrapper for keyboard handling
  screen: {
    flex: 1,
    backgroundColor: "#f8f5fb",
  },

  // Scrollable content container
  container: {
    padding: 20,
    backgroundColor: "#f8f5fb",
    flexGrow: 1,
    paddingBottom: 40,
  },

  title: {
    fontSize: 28,
    fontWeight: "700",
    marginBottom: 24,
    textAlign: "center",
    color: "#2b0540",
  },

  label: {
    fontWeight: "700",
    fontSize: 15,
    marginBottom: 8,
    marginTop: 6,
    color: "#2b0540",
  },

  input: {
    borderWidth: 1,
    borderColor: "#d9d2e1",
    padding: 12,
    marginBottom: 12,
    borderRadius: 12,
    backgroundColor: "#fff",
  },

  selectInput: {
    borderWidth: 1,
    borderColor: "#d9d2e1",
    padding: 14,
    marginBottom: 12,
    borderRadius: 12,
    backgroundColor: "#fff",
  },

  selectInputText: {
    color: "#111",
    fontWeight: "600",
  },

  notesInput: {
    minHeight: 100,
    textAlignVertical: "top",
  },

  rowWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginBottom: 12,
  },

  chipBtn: {
    borderWidth: 1,
    borderColor: "#d6c3e6",
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: "#fff",
  },

  chipBtnSelected: {
    backgroundColor: "#2b0540",
    borderColor: "#2b0540",
  },

  chipText: {
    fontWeight: "600",
    color: "#2b0540",
  },

  chipTextSelected: {
    color: "#fff",
  },

  submitBtn: {
    backgroundColor: "#da9306",
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 10,
  },

  submitBtnText: {
    color: "#2b0540",
    textAlign: "center",
    fontWeight: "700",
    fontSize: 16,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    justifyContent: "center",
    paddingHorizontal: 20,
  },

  modalCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    maxHeight: "70%",
  },

  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#2b0540",
    marginBottom: 12,
    textAlign: "center",
  },

  modalItem: {
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },

  modalItemText: {
    color: "#111",
    fontSize: 15,
    fontWeight: "600",
  },

  inputText: {
    color: "#111",
    fontWeight: "500",
  },

  inlinePickerCard: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 10,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#ddd",
  },

  pickerButtonsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },

  cancelBtn: {
    padding: 10,
  },

  cancelText: {
    color: "#888",
    fontWeight: "600",
  },

  confirmBtn: {
    backgroundColor: "#da9306",
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
  },

  confirmText: {
    color: "#2b0540",
    fontWeight: "700",
  },
});